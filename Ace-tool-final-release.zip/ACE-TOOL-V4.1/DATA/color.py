  _______        .__                       
 /_  ___ \  ____ |  |   ___________  ______
/    \  \/ /  _ \|  |  /  _ \_  __ \/  ___/
\     \___(  <_> )  |_(  <_> )  | \/\___ \ 
 \______  /\____/|____/\____/|__|  /____  >
 ===================================================
 a : retourner au menu
 b : Couleur blanc sur noir
 c : Couleur noir sur blanc
 d : Couleur cyan sur noir
 e : Couleur bleu (par defaut)
 f : Couleur noir sur rouge
 g : Couleur rouge sur noir 
 h : Jaune sur noir 
 i : Noir sur jaune
 ===================================================
 