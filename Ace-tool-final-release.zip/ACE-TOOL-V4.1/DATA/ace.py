                              db        .g8"""bgd `7MM"""YMM      MMP""MM""YMM   .g8""8q.     .g8""8q.   `7MMF'      
                             ;MM:     .dP'     `M   MM    `7      P'   MM   `7 .dP'    `YM. .dP'    `YM.   MM        
                            ,V^MM.    dM'       `   MM   d             MM      dM'      `MM dM'      `MM   MM        
                           ,M  `MM    MM            MMmmMM             MM      MM        MM MM        MM   MM        
                           AbmmmqMA   MM.           MM   Y  ,          MM      MM.      ,MP MM.      ,MP   MM      , 
                          A'     VML  `Mb.     ,'   MM     ,M          MM      `Mb.    ,dP' `Mb.    ,dP'   MM     ,M 
                        .AMA.   .AMMA.  `"bmmmd'  .JMMmmmmMMM        .JMML.      `"bmmd"'     `"bmmd"'   .JMMmmmmMMM 
====================================================== https://discord.gg/acev2 ======================================================

> Pour quitter entrez 50 comme choix
> V4.1 30/09/22
> Pour rejoindre le discord entrez "0" comme choix

 -----------CATEGORIE DARK NET------------  | -----------CATEGORIE UTILITAIRE----------- | -----------CATEGORIE GENERAL----------- |
                                            |                                            |                                         |
 1. installer TOR                           | 9.Pinger                                   |17.Voir les DLC disponibles              |
                                            |                                            |                                         |
 2. lancer le repertoir du dark net         | 10.Administrateur                          |18.Changer le menu de couleurs           |
                                            |                                            |                                         |
 3. voir les differents market du dark net  | 11.Eteindre ordi a distance                |19.Voir les logs                         |
                                            |                                            |                                         |
 4. voir les forums du dark net             | 12.Execute un scan de l'ordinateur         |20.Annalyse de virus systeme             |
                                            |                                            |                                         |
 5. voir les sites de hacking du dark net   | 13.Generateur de visage                    |21.Voir les mises a jour disponibles     |
                                            |                                            |                                         |
 --------CATEGORIE FAUX VIRUS ------------  | 14.Changer d'ipv4 (BETA)                   |22.Carateristiques du pc                 |
                                            |                                            |                                         |
 6.Deconnexion constante des reseaux        | 15.Heure en direct                         |23.Supprimer les fichiers temporaires    |
                                            |                                            |                                         |
 7.Reconnexion aux reseaux                  | -------------CATEGORIE VIRUS-------------- |24.Connexion ftp                         |
                                            |                                            |                                         |
 8.Faux ransomware                          | 16.Virus infermable                        |25.Sites utiles                          |
                                            |                                            |                                         |
 -----------------------------------------  | ------------------------------------------ | --------------------------------------- |
 <<Page precedente (0)                                        Page 1                                         (1000) Page suivante >>
===========================================================================================================================================
 

