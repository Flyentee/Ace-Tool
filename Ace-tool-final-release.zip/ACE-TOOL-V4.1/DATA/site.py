                                       _____ ______   _______ ____   ____  _       _____ 
                                 /\   / ____|  ____| |__   __/ __ \ / __ \| |     / ____|
                                /  \ | |    | |__       | | | |  | | |  | | |    | (___  
                               / /\ \| |    |  __|      | | | |  | | |  | | |     \___ \ 
                              / ____ \ |____| |____     | | | |__| | |__| | |____ ____) |
                             /_/    \_\_____|______|    |_|  \____/ \____/|______|_____/ 


=========================================== https://discord.gg/ZjtdSGvYFj ==========================================

>Pour revenir au menu faites "0"

===================================================SITES UTILES=====================================================

1. 10 MINUTE E-MAIL : vous genere une adresse mail qui sera Supprimer 10 min apres 

2. MATHway : Comme une calculatrice mais en plus complexe 

3. Fake name generator : genere des fausses personnes 

4. What The Font : voir quelle police vous conviendrais le mieux

5. Camel Camel Camel : Voir a quelle moment acheter ses produits sur Amazon

6. ONLINE ETYMOLOGY DICTIONARY : Un dictionnaire en plus complexe 

7. ACCOUNT KILLER : permet de supprimer vos compte (facebook, gmail, Whatsapp ...)

8. WHAT THE F*CK SHOULD I MAKE FOR DINNER : Vous ne savez pas quoi manger ?? ce site vous donne des plats aleatoires

9. DOWN FOR EVERYONE OR JUST ME : Savoir si un site ne marche plus ou si c'est juste vous

10. DATE TO DATE CALCULATOR : son nom dit tout !

=====================================================================================================================
<< Page precedente (0)                             Page 1                                         (100) Page suivante>>     

