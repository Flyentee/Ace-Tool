                          _____ ______   _______ ____   ____  _       _____ 
                    /\   / ____|  ____| |__   __/ __ \ / __ \| |     / ____|
                   /  \ | |    | |__       | | | |  | | |  | | |    | (___  
                  / /\ \| |    |  __|      | | | |  | | |  | | |     \___ \ 
                 / ____ \ |____| |____     | | | |__| | |__| | |____ ____) |
                /_/    \_\_____|______|    |_|  \____/ \____/|______|_____/ 


=============================== https://discord.gg/ZjtdSGvYFj ===============================

> Pour revenir au menu entrez "1" comme choix

==============================================================================================
Cette outil vous permet de devenir administrateur sur les pc du college/lycee, 
Pour cela suivez les etapes suivantes : 

1.Activez le tools "administrateur"
2.Rallumer l'ordinateur 
3.Activez le tools "reconnexion aux reseaux"
4.Vous etes maintenant Administrateur du systeme !

==============================================================================================

1.revenir au menu

2.Activer "Administrateur"

