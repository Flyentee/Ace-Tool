                                       _____ ______   _______ ____   ____  _       _____ 
                                 /\   / ____|  ____| |__   __/ __ \ / __ \| |     / ____|
                                /  \ | |    | |__       | | | |  | | |  | | |    | (___  
                               / /\ \| |    |  __|      | | | |  | | |  | | |     \___ \ 
                              / ____ \ |____| |____     | | | |__| | |__| | |____ ____) |
                             /_/    \_\_____|______|    |_|  \____/ \____/|______|_____/ 


=========================================== https://discord.gg/ZjtdSGvYFj ==========================================

>Pour revenir au menu faites "0"

===================================================SITES UTILES=====================================================

11. receive-sms : recois les sms a votre place pr les verifs sur les sites 

12. skyscanner : Quand tu veux partir loin, meme si tu ne sais pas encore ou

13. Photopea : photoshop en gratuit 

14. strip creator : pour devenir le prochain Stan Lee

15. Adobe Kuler : tu ne veux pas passer 4h a chercher les bons accords de couleurs sur Illustrator

16. ViddyJam : Pour retrouver toute tes playlistes 

17. The Rasterbator : Pour dessiner sur un feuille

18. The Scale of the Universe 2 : tu veux te rendre compte de la taille de l Univers

19. Can I Stream It ? : pour te faire une soiree streaming

20. ManualsLib : Pour retrouver les notices que tu as perdu

=====================================================================================================================
<< Page precedente (50)                             Page 2                                         (0) Page suivante>>     

