                              db        .g8"""bgd `7MM"""YMM      MMP""MM""YMM   .g8""8q.     .g8""8q.   `7MMF'      
                             ;MM:     .dP'     `M   MM    `7      P'   MM   `7 .dP'    `YM. .dP'    `YM.   MM        
                            ,V^MM.    dM'       `   MM   d             MM      dM'      `MM dM'      `MM   MM        
                           ,M  `MM    MM            MMmmMM             MM      MM        MM MM        MM   MM        
                           AbmmmqMA   MM.           MM   Y  ,          MM      MM.      ,MP MM.      ,MP   MM      , 
                          A'     VML  `Mb.     ,'   MM     ,M          MM      `Mb.    ,dP' `Mb.    ,dP'   MM     ,M 
                        .AMA.   .AMMA.  `"bmmmd'  .JMMmmmmMMM        .JMML.      `"bmmd"'     `"bmmd"'   .JMMmmmmMMM 
=================================================== https://discord.gg/ZjtdSGvYFj =========================================================

> Pour revenir au menu, entrez "0" comme choix

===========================================================================================================================================

1.Pine-tool : retouche rapide

2.Photopea : Photoshop gratuit

3.Clip drop : Refaire la luminosite de vos image

4.Logo maker : creer votre logo

5.Pfp maker : creer votre photo de profil 

===========================================================================================================================================

