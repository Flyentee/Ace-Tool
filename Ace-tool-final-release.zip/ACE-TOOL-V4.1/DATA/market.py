           _____ ______   _______ ____   ____  _       _____ 
     /\   / ____|  ____| |__   __/ __ \ / __ \| |     / ____|
    /  \ | |    | |__       | | | |  | | |  | | |    | (___  
   / /\ \| |    |  __|      | | | |  | | |  | | |     \___ \ 
  / ____ \ |____| |____     | | | |__| | |__| | |____ ____) |
 /_/    \_\_____|______|    |_|  \____/ \____/|______|_____/ 


-------------------- https://discord.gg/ZjtdSGvYFj--------------------

> Entrez "0" pour revenir au menu

---------------LES MARKETS---------------

1- Blackmarket : http://blackma6xtzkajcy2eahws4q65ayhnsa6kghu6oa6sci2ul47fq66jqd.onion/  

2- Caribbean Cards : http://caribcc5jik7maeqfit7h34af7ntatggbmlfhyxjnqnrhij7gjt5vtid.onion/

3- Psy Shop : http://psyshopshweetovp4em654waimmcjsf7eqifwe2d4qhnluk2b24r6dqd.onion/

4- Cardzilla : http://cardzilevs4j4nj6uswfwf35oxnp64yrrtazjgap2w3vgoz2pwkp6sqd.onion/

5- 21 Million Club : http://million5utxgrxru4rqmjwn7jji6bf44jkdqn3xyav6md5ebwy5l2ryd.onion/

6- The Escrow : http://escrowkwttyhfyab3clkln7lfveyg7pfdwsv5vner35mhg7oaqz5uiid.onion/

-----------------------------------------



